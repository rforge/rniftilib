DisplaySurface<-function(Surface)
{
# visualize skin
	if(require(rgl)) { 
	  #rgl.open()
	  rgl.points(Surface$vertices)
	
	  tx=Surface$vertices[t(Surface$triangles),1]
	  ty=Surface$vertices[t(Surface$triangles),2]
	  tz=Surface$vertices[t(Surface$triangles),3]
	  rgl.triangles(tx,ty,tz,lit=FALSE,color="white",alpha=0.5);
	}
}