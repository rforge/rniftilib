Norm<-function(v1)
{
  sqrt(sum(v1^2));
}

Dotproduct<-function(v1,v2)
{
   (t(v1) %*% v2);
}

Orthogonal<-function(v1,v2)
{
  v2-Dotproduct(v1,v2)/Dotproduct(v1,v1)*v1;
}

GetOrth<-function(v1)
{
  retval=Orthogonal(v1,c(0,1))
  if((retval[1]==0) & (retval[2]==0))
  { retval=Orthogonal(v1,c(1,0)); }
  retval;
}

Normalize<-function(v1)
{
 v1/Norm(v1);
}

correctdir<-function(v_pix,dir,center)
{
  diffx1=v_pix$x-dir$x-center$x;
  diffy1=v_pix$y-dir$y-center$y;

  diffx2=v_pix$x+dir$x-center$x;
  diffy2=v_pix$y+dir$y-center$y;

  d=sign(sqrt(diffx1*diffx1+diffy1*diffy1)-sqrt(diffx2*diffx2+diffy2*diffy2))
  list(x=-d*dir$x,y=-d*dir$y)
}

correctdir2<-function(v_pix,dir,center)
{
  diffx1=v_pix[1]-dir[1]-center$x;
  diffy1=v_pix[2]-dir[2]-center$y;

  diffx2=v_pix[1]+dir[1]-center$x;
  diffy2=v_pix[2]+dir[2]-center$y;

  d=sign(sqrt(diffx1*diffx1+diffy1*diffy1)-sqrt(diffx2*diffx2+diffy2*diffy2))
  c(-d*dir[1],y=-d*dir[2])
}

scandir<-function(nifti,point,slice,dir,max_distance=40)
{
  distance=(max_distance:-max_distance)/2;
  val=numeric(length(distance));
  for(i in 1:length(distance))
  {
    val[i]=nifti.interpolate3d(nifti, point[1]+dir[1]*distance[i], point[2]+dir[2]*distance[i], slice);
  }
  list(distance=distance,val=val);
}

trace_values<-function(distance,val,p=0.1)
{
  thres=min(val)+(max(val)-min(val))*p;
  index=1;
  while((val[index]<thres) && (index<length(distance))) {index=index+1;}
  distance[index];
}

calcdir<-function(v_pix)
{
  vec=list(x=v_pix$x[2:length(v_pix$x)]-v_pix$x[1:(length(v_pix$x)-1)],
           y=v_pix$y[2:length(v_pix$x)]-v_pix$y[1:(length(v_pix$x)-1)]);
  vec$x=c(vec$x,-(v_pix$x[length(v_pix$x)]-v_pix$x[length(v_pix$x)-1]));
  vec$y=c(vec$y,-(v_pix$y[length(v_pix$y)]-v_pix$y[length(v_pix$y)-1]));
  vec;
}

sample_eq<-function(v_pix,no)
{
  diffx=v_pix$x[2:length(v_pix$x)]-v_pix$x[1:(length(v_pix$x)-1)];
  diffy=v_pix$y[2:length(v_pix$x)]-v_pix$y[1:(length(v_pix$y)-1)];
  len=sqrt(diffx*diffx+diffy*diffy);
  len=c(0,len);
  steps=sum(len)/(no-1);
  pos=list(x=numeric(no),y=numeric(no))
  print(len)
  pos$x[1]=v_pix$x[1];
  pos$y[1]=v_pix$y[1];
  for(i in 1:(no-1))
  {
    j=1;
    while((j < length(len)) & (i*steps>sum(len[1:j]))) { j=j+1; }
    pos$x[i+1]=v_pix$x[j-1]+diffx[j-1]/len[j]*(i*steps-sum(len[1:j-1]));
    pos$y[i+1]=v_pix$y[j-1]+diffy[j-1]/len[j]*(i*steps-sum(len[1:j-1]));    
  }
  pos
}

Rdev2pix<-function(nifti_img,v)
{
  list(x=v$x*dim(nifti_img)[1],y=v$y*dim(nifti_img)[2]);
}


DrawPolyline<-function(nifti_img,polyline_pix,...)
{
  points(polyline_pix$x/dim(nifti_img)[1],polyline_pix$y/dim(nifti_img)[2],...);
  n=length(polyline_pix$x)
  dir=calcdir(polyline_pix);
  center=list(x=mean(polyline_pix$x),y=mean(polyline_pix$y));

  for( i in 1:n )
  {
    vec=list(x=dir$x[i],y=dir$y[i]);   
    orth_vec=Normalize(GetOrth(c(vec$x,vec$y)));
    orth_vec=correctdir2(c(polyline_pix$x[i],polyline_pix$y[i]),orth_vec,center);
    lines(c(polyline_pix$x[i],polyline_pix$x[i]+orth_vec[1]*10)/dim(nifti_img)[1],
          c(polyline_pix$y[i],polyline_pix$y[i]+orth_vec[2]*10)/dim(nifti_img)[2],...)
  }
}

FitPolyline<-function(nifti_img, slice, polyline_pix, thres = 0.3)
{
  dir=calcdir(polyline_pix);
  center=list(x=mean(polyline_pix$x,na.rm = TRUE),y=mean(polyline_pix$y,na.rm = TRUE));

  n=length(polyline_pix$x)
  new_v_pix=list(x=numeric(n),y=numeric(n));
  for( i in 1:n )
  {
    vec=list(x=dir$x[i],y=dir$y[i]);     
    orth_vec=Normalize(GetOrth(c(vec$x,vec$y)));
    
    currentpoint=c(polyline_pix$x[i],polyline_pix$y[i]);
    orth_vec=correctdir2(currentpoint,orth_vec,center);      
    val=scandir(nifti_img,currentpoint,slice,orth_vec);
    d=trace_values(val$distance,val$val,thres);
    newpos=c(currentpoint[1]+orth_vec[1]*d, currentpoint[2]+orth_vec[2]*d);
    new_v_pix$x[i]=newpos[1];
    new_v_pix$y[i]=newpos[2];
  }
  new_v_pix;
}

#intersect<-function(la,lb,p0,p1,p2)
#{
# a1=c(la[1]-lb[1],p1[1]-p0[1],p2[1]-p0[1])
# a2=c(la[2]-lb[2],p1[2]-p0[2],p2[2]-p0[2])
# a3=c(la[3]-lb[3],p1[3]-p0[3],p2[3]-p0[3])
# A=rbind(a1,a2,a3);
# b=c(la[1]-p0[1],la[2]-p0[2],la[3]-p0[3]);
#  try(solve(A, b));
#}

TraceSurface<-function(nifti_img, start_slice, end_slice, poly_n=10, thres = 0.3, samples_slice=30)
{
  image(nifti_img[,, start_slice,],col=gray(1:255/255));
  v=locator(poly_n,type="l",col="green")
  v_pix=Rdev2pix(nifti_img,v);

  data=c();

  for(slice in start_slice:end_slice)
  {
    image(nifti_img[,,slice,],col=gray(1:255/255));
    text(0.3,0.05,label=sprintf("slice %d (processing slice %d - %d)",slice,start_slice,end_slice),col="white");
    DrawPolyline(nifti_img,v_pix,col="red");
    print(v_pix);
    new_v_pix=FitPolyline(nifti_img, slice, v_pix, thres);
    print(new_v_pix);

    DrawPolyline(nifti_img,new_v_pix,col="blue");
    re_v_pix=sample_eq(new_v_pix,samples_slice) 
    new_re_v_pix=FitPolyline(nifti_img, slice, re_v_pix, thres);
  
    DrawPolyline(nifti_img,new_re_v_pix,col="green",lw=2);
    data=rbind(data,cbind(new_re_v_pix$x,new_re_v_pix$y,rep(slice,length(new_re_v_pix$y))));
    v_pix=new_re_v_pix;
  }  
  # convert pix to mm
  for(index in 1:(dim(data)[1]))
  {
    data[index,] = (nifti_img$qto.xyz %*% c(data[index,],1))[1:3];
  }
  triangles=matrix(nrow=(samples_slice-1)*abs(end_slice-start_slice)*2,ncol=3);
  i=1;
  for(index in 1:(length(data[,1])-samples_slice))
  {
    if((index %% samples_slice)!=0)
    {    
      triangles[i,] = c(index,index+samples_slice,index+samples_slice+1); i=i+1;
      triangles[i,] = c(index,index+samples_slice+1,index+1);  i=i+1;
    }
  }
  list(vertices=data, triangles=triangles);
}
