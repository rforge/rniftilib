TraceSurfaceGUI<-function(image)
{
SurfaceTrimesh=c()
if(require(tcltk) & require(Rniftilib)) {
	tt <- tktoplevel()
	# Give the window a title
	tkwm.title(tt,"3D surface trancing (Rniftitools)")
	
	label.widget.startslice <- tklabel(tt, text="start slice")
	startslice <- tclVar("15")
	entry.widget.startslice <- tkentry(tt,textvariable=startslice)
	
	label.widget.endslice <- tklabel(tt, text="end slice")
	endslice <- tclVar(dim(image)[3]-15)
	entry.widget.endslice <- tkentry(tt,textvariable=endslice)
	
	# three additional parameters for contour tracing
	label.widget.poly_n <- tklabel(tt, text="number of points to specify initial polygon")
	poly_n <- tclVar(10)
	entry.widget.poly_n <- tkentry(tt,textvariable=poly_n)
	
	label.widget.thres <- tklabel(tt, text="threshold")
	thres <- tclVar(0.3)
	entry.widget.thres <- tkentry(tt,textvariable=thres)
	
	label.widget.samples_slice <- tklabel(tt, text="number of samples/slice in final surface")
	samples_slice <- tclVar(30)
	entry.widget.samples_slice <- tkentry(tt,textvariable=samples_slice)
	
	
	
	button.widget.start <- tkbutton(tt, text="Start tracing...",
	                       command=function(){
	 
	 start_slice=as.integer(tclvalue(startslice));
	 end_slice=as.integer(tclvalue(endslice));
	 poly_n_value=as.integer(tclvalue(poly_n));
	 thres_value=as.numeric(tclvalue(thres));
	 samples_slice_value=as.integer(tclvalue(samples_slice));
	 print(thres_value);
	 SurfaceTrimesh <<- TraceSurface(image, start_slice, end_slice, poly_n_value, thres_value, samples_slice_value);
	})
	
	button.widget.showstart <- tkbutton(tt, text="Display start slice...",
	                       command=function()plot(image,dim3=as.integer(tclvalue(startslice))))
	
	button.widget.showend <- tkbutton(tt, text="Display end slice...",
	                       command=function()plot(image,dim3=as.integer(tclvalue(endslice))))
	
	button.widget.showlimits <- tkbutton(tt, text="Display start+end slices...",
	                       command=function(){
	dim1=1:dim(image)[1];
	dim2=round(dim(image)[2]/2);
	dim3=1:dim(image)[3];
	start=as.integer(tclvalue(startslice))
	end=as.integer(tclvalue(endslice))
	image(dim1, dim3 , image[dim1, dim2, dim3], col = gray(1:255/255))
	lines(c(1,dim(image)[1]),c(start,start),col="green");
	lines(c(1,dim(image)[1]),c(end,end),col="green");
	arrows(dim(image)[1]/2,start,dim(image)[1]/2,end,col="green",lwd=2);
	})
	
	button.widget.showmesh <- tkbutton(tt, text="Display mesh in 3D (requires rgl-package)...",
	                       command=function(){
	 DisplaySurface(SurfaceTrimesh);
	})
	
	button.widget.savemesh <- tkbutton(tt, text="Save triangle mesh in .RData format...",
	                       command=function(){
	# save mesh in .RData format
	save(SurfaceTrimesh, file=file.choose());	
	})
		
	# geometry manager (add all widgets to window)
	# see Tk-commands
	tkpack(label.widget.startslice,entry.widget.startslice) 
	tkpack(label.widget.endslice,entry.widget.endslice) 
	tkpack(button.widget.showstart,button.widget.showend,button.widget.showlimits)
	
	tkpack(label.widget.poly_n,entry.widget.poly_n);
	tkpack(label.widget.thres,entry.widget.thres);
	tkpack(label.widget.samples_slice,entry.widget.samples_slice);
	tkpack(button.widget.start,button.widget.showmesh,button.widget.savemesh);
		
	tkwait.window(tt);
	tkdestroy(tt);
} else
  warning("aborted: \"tcltk\" and \"Rniftilib\" package required!");
SurfaceTrimesh
}
